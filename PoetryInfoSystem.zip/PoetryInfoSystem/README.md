# PoetryINfoSystem

python环境：python3.X
依赖的包或框架：requests, BeautifulSoup, re, Django框架

下载文件到某个文件夹，然后运行，根据提示执行程序，
进入PoetryINfoSystem文件夹, 运行程序
```python
python3 manage.py runserver
```
文档集合存储于 `poems.txt` 文件中

爬虫代码位于`Spider/spider.py`中


